# Pump Startup SOP

<!-- OKF_METADATA: {} -->

Verify PT-101 pressure before starting Pump P-101A.