# API Document Spec

<!-- OKF_METADATA: {} -->

API routing rules and schema compliance parameters.